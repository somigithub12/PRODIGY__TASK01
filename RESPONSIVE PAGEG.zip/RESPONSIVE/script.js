burgur = document.queryselector(.'burgur')
navbar = document.queryselector(.'navbar')
nav-list = document.queryselector(.'nav-list')
rightNav = document.queryselector(.'rightNav')

burgur.addEventListener('click' , ()=>{
   rightbar.classList.toggle('v-class-resp');
   navbar.classList.toggle('v-class-resp');
})